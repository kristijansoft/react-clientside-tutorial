﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace RelayServiceProxy.Models
{
    public class Documents
    {
        public string Title { get; set; }
        public string FileRef { get; set; }
        public string FileLeafRef { get; set; }
        public string CreatedDate { get; set; }
        public string LastModified { get; set; }
        public string Author { get; set; }
        public string Editor { get; set; }
        public int FileSize { get; set; }
    }
}