﻿using Microsoft.ServiceBus;
using RelayServiceDemoService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.ServiceModel;
using System.Web.Http;

namespace RelayServiceProxy.Controllers
{
    public class DocumentController : ApiController
    {
        static ChannelFactory<IDocumentsChannel> channelFactory;
        static DocumentController()
        {
            // Create shared access signature token credentials for authentication.
            channelFactory = new ChannelFactory<IDocumentsChannel>(new NetTcpRelayBinding(),
                "sb://yourNamespace.servicebus.windows.net/documents");
            channelFactory.Endpoint.Behaviors.Add(new TransportClientEndpointBehavior
            {
                TokenProvider = TokenProvider.CreateSharedAccessSignatureTokenProvider(
                    "RootManageSharedAccessKey", "yourkey")
            });
        }

        public IList<DocumentData> Get(string webID)
        {
            using (IDocumentsChannel channel = channelFactory.CreateChannel())
            {

                try {
                    var results= channel.GetDocuments(webID);
                    return results;
                }catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                    return null;
                }

            }
        }

    }
}
