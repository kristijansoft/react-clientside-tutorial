﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace RelayServiceDemoService
{
    // Define the data contract for the service
    [DataContract]
    // Declare the serializable properties.
    public class DocumentData
    {
        [DataMember]
        public string Title { get; set; }
        [DataMember]
        public string ServerRelativeUrl { get; set; }
        [DataMember]
        public string FileName { get; set; }
        [DataMember]
        public string CreatedDate { get; set; }
        [DataMember]
        public string LastModified { get; set; }
        [DataMember]
        public string Author { get; set; }
        [DataMember]
        public string Editor { get; set; }
        [DataMember]
        public int FileSize { get; set; }

    }

    // Define the service contract.
    [ServiceContract]
    interface IDocuments
    {
        [OperationContract]
        IList<DocumentData> GetDocuments(string WebId);

    }

    interface IDocumentsChannel : IDocuments, IClientChannel
    {
    }

}
