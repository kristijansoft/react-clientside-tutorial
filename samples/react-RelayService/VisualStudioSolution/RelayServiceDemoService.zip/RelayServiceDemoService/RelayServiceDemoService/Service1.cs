﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace RelayServiceDemoService
{
    public partial class Service1 : ServiceBase, IDocuments

    {
        private ServiceHost serviceHost; // this is the host that will listen for messages
        public Service1()
        {
            InitializeComponent();
            eventLog1 = new System.Diagnostics.EventLog();
            if (!System.Diagnostics.EventLog.SourceExists("RelaySource"))
            {
                System.Diagnostics.EventLog.CreateEventSource(
                    "RelaySource", "RelayLog");
            }
            eventLog1.Source = "RelaySource";
            eventLog1.Log = "RelayLog";
        }
        protected override void OnStart(string[] args)
        {
            eventLog1.WriteEntry("In OnStart");
            try
            {
                serviceHost = new ServiceHost(typeof(Service1));
                eventLog1.WriteEntry("Created Service Host");
                serviceHost.Open();
            }
            catch (Exception e)
            {
                eventLog1.WriteEntry("Error" + e.Message);

            }


            eventLog1.WriteEntry("Service Host Opened");

        }

        protected override void OnStop()
        {
            eventLog1.WriteEntry("In OnStop");
            serviceHost.Close();
            eventLog1.WriteEntry("Service Host Closed");
        }

        public IList<DocumentData> GetDocuments(string WebId)
        {
            eventLog1.WriteEntry("GetDocuments called for webID " + WebId);
            try
            {
                List<DocumentData> docs = new List<DocumentData>();
                using (ClientContext context = new ClientContext(ConfigurationSettings.AppSettings["App.Url"]))

                {

                    eventLog1.WriteEntry("Created Client context ");
                    context.RequestTimeout = 24000;
                    string user = ConfigurationSettings.AppSettings["App.User.Id"];
                    string password = ConfigurationSettings.AppSettings["App.User.Password"];
                    string domain = ConfigurationSettings.AppSettings["App.User.Domain"];
                    context.Credentials = new NetworkCredential(user, password, domain);
                    Web web = context.Site.OpenWebById(new Guid(WebId));
                    context.ExecuteQuery();
                    eventLog1.WriteEntry("Opened web");
                    List list = web.Lists.GetByTitle("Document Library");// change the name to match your library name
                    CamlQuery camlQuery = new CamlQuery();
                    camlQuery.ViewXml = @"<View><RowLimit>100</RowLimit><ViewFields>
                <FieldRef Name = 'ID'></FieldRef>
                <FieldRef Name = 'Title'></FieldRef>
                <FieldRef Name = 'FileRef'></FieldRef>
                <FieldRef Name = 'FileLeafRef'></FieldRef>
                <FieldRef Name = 'Created_x0020_Date'></FieldRef>
                <FieldRef Name = 'Last_x0020_Modified' ></FieldRef>
                <FieldRef Name = 'Author' ></FieldRef>
                <FieldRef Name = 'Editor' ></FieldRef>
                <FieldRef Name = 'File_x0020_Size' ></FieldRef>
                </ViewFields></View>";
                    ListItemCollection collListItem = list.GetItems(camlQuery);
                    context.Load(collListItem);
                    context.ExecuteQuery();
                    eventLog1.WriteEntry("Got ListItems");
                    foreach (ListItem item in collListItem)
                    {
                        eventLog1.WriteEntry(String.Format("ID: {0} \nTitle: {1} ", item.Id, item["Title"]));
                        docs.Add(new DocumentData()
                        {
                            Title = (string)item["Title"],
                            FileName = (string)item["FileLeafRef"],
                            ServerRelativeUrl = (string)item["FileRef"],
                            CreatedDate = (string)item["Created_x0020_Date"],// keep it as string for powerapps
                            LastModified = (string)item["Last_x0020_Modified"],
                            Author = ((FieldUserValue)item["Author"]).Email,
                            Editor = ((FieldUserValue)item["Editor"]).Email,
                            FileSize = Convert.ToInt32((string)item["File_x0020_Size"])

                        });

                    }
                }
                eventLog1.WriteEntry("Completed GetDocuments for webID " + WebId);
                return docs;
            }catch(Exception e)
            {
                eventLog1.WriteEntry(e.Message);
                return null;

            }
        }


    }
}
